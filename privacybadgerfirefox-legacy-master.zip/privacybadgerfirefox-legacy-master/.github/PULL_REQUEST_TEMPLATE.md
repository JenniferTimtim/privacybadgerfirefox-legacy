# IMPORTANT 
This version of privacy badger is no longer maintained. All of the source code for privacy badger for Firefox, Chrome, and Opera now lives in one repository at: https://github.com/EFForg/privacybadger

Pull requests opened on this repository will not be merged. 
