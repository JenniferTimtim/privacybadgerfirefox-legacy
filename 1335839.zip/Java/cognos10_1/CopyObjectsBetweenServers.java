/**
 * CopyObjectsBetweenServers.java
 *
 * Licensed Material - Property of IBM
 * � Copyright IBM Corp. 2003, 2010 
 *
 * Description: Technote 1335839 - SDK sample to copy Objects between different servers
 * 
 * Tested with: IBM Cognos BI 10.1, IBM Java 5.0 
 * 
 */
import java.net.MalformedURLException;
import org.apache.axis.client.Stub;
import org.apache.axis.message.SOAPHeaderElement;

import java.rmi.RemoteException;
import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;
import com.cognos.developer.schemas.bibus._3.*;

public class CopyObjectsBetweenServers {
	
	private ContentManagerService_PortType cmService_from    = null;
	private ContentManagerService_PortType cmService_to    = null;
	public final String endPoint_from = "http://<server1>:9300/p2pd/servlet/dispatch"; 
	public final String endPoint_to = "http://<server2>:9300/p2pd/servlet/dispatch"; 
			

	public static void main(String[] args) {
		CopyObjectsBetweenServers cp = new CopyObjectsBetweenServers();
		
		XmlEncodedXML credentials_from = cp.setCredentials("SDK1", "admin", "password");
		XmlEncodedXML credentials_to = cp.setCredentials("SDK2", "admin", "password");
		
		String reportSPath_from = "/content/folder[@name='Samples']/folder[@name='Models']/package[@name='GO Data Warehouse (query)']/folder[@name='SDK Report Samples']/folder[@name='SDK Additional Report Samples']//report";
		//if reportSPath_to does not exist on server2, an error will be displayed
		String reportSPath_to = "/content/folder[@name='Samples']/folder[@name='Models']/package[@name='GO Data Warehouse (query)']/folder[@name='test']";
		
		SearchPathSingleObject spSingle = new SearchPathSingleObject();
		//logon to both servers
		try
		{		
			cp.getCmService_from().logon(credentials_from, new SearchPathSingleObject[]{});
			cp.getCmService_to().logon(credentials_to, new SearchPathSingleObject[]{});			
			
			//specific for Cognos 10.1 - we need to explicitly set the BiBusHeader of the ContentManagerService object
			cp.setBiBusHeader(cp.getCmService_from());
			cp.setBiBusHeader(cp.getCmService_to());
		}catch (Exception e)
		{e.printStackTrace();}
		
		BaseClass objectsToAdd[] = new BaseClass []{};
		objectsToAdd = cp.queryCognosBI_from(reportSPath_from);
		cp.setParentObject(objectsToAdd, reportSPath_to);
		try {
			AddOptions opt = new AddOptions();
			opt.setUpdateAction(UpdateActionEnum.replace);
			spSingle.set_value(reportSPath_to);
			//if the reports already exist on server2 an error is displayed
			cp.getCmService_to().add(spSingle, objectsToAdd, opt);
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("Finished copying reports from server1 to server2");
	}
	
	public void setParentObject(BaseClass objects[], String s_repParentSearchPath)
	{
//		Set report parent - this will be the package containing the report
		StringProp tParent = new StringProp();
		tParent.setValue(s_repParentSearchPath);		
		Nil bcParent = new Nil();
		BaseClass[] reportParent = {bcParent};
		reportParent[0].setSearchPath(tParent);	
		BaseClassArrayProp parent = new BaseClassArrayProp();
		parent.setValue(reportParent);
		for (int i=0; i<objects.length; i++)
		{
			objects[i].setParent(parent);
		}
	}
	
	
	public BaseClass[] queryCognosBI_from(String reportSPath_from)
	{
		PropEnum props[] = getAllPropEnum();
		BaseClass bc[] = null;
		SearchPathMultipleObject spMulti = new SearchPathMultipleObject(reportSPath_from);
		try
		{
			bc = cmService_from.query(spMulti, 
					props, new Sort[]{}, new QueryOptions());
			
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		return bc;
	}
	
	public CopyObjectsBetweenServers()
	{		
	   ContentManagerService_ServiceLocator cmServiceLocator = new ContentManagerService_ServiceLocator();
	   try {
		cmService_from = cmServiceLocator.getcontentManagerService(new java.net.URL(endPoint_from));
		cmService_to = cmServiceLocator.getcontentManagerService(new java.net.URL(endPoint_to));
		
		
	} catch (MalformedURLException e) {
		e.printStackTrace();
	} catch (ServiceException e) {
		e.printStackTrace();
	}
}
	
	
	public void setBiBusHeader(ContentManagerService_PortType cmService){
		try
		{
			//Set the BiBusHeader
			SOAPHeaderElement temp = ((Stub)cmService).getResponseHeader 
				("http://developer.cognos.com/schemas/bibus/3/", "biBusHeader");
			
			BiBusHeader cmBiBusHeader = (BiBusHeader)temp.getValueAsType
				(new QName ("http://developer.cognos.com/schemas/bibus/3/","biBusHeader"));
			
			((Stub)cmService).setHeader
				("http://developer.cognos.com/schemas/bibus/3/", "biBusHeader", cmBiBusHeader);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
//	This method created the credentials for the user to logon
	public XmlEncodedXML setCredentials(String namespace, String uid, String pwd)
	{
		StringBuffer credentialXML = new StringBuffer();

		credentialXML.append("<credential>");
		credentialXML.append("<namespace>").append(namespace).append("</namespace>");
		credentialXML.append("<username>").append(uid).append("</username>");
		credentialXML.append("<password>").append(pwd).append("</password>");
		credentialXML.append("</credential>");
		
		String encodedCredentials = credentialXML.toString();
	    XmlEncodedXML xmlCredentials = new XmlEncodedXML();
	    xmlCredentials.set_value(encodedCredentials);

		return xmlCredentials;
	}
	

	public PropEnum[] getAllPropEnum ()
	  {
	    PropEnum properties[] = new PropEnum[]{
	      PropEnum.active,
	      PropEnum.actualCompletionTime,
	      PropEnum.actualExecutionTime,
	      PropEnum.advancedSettings,
	      PropEnum.ancestors,
	      PropEnum.asOfTime,
	      PropEnum.base,
	      PropEnum.brsAffineConnections,
	      PropEnum.brsMaximumProcesses,
	      PropEnum.brsNonAffineConnections,
	      PropEnum.burstKey,
	      PropEnum.businessPhone,
	      PropEnum.canBurst,
	      PropEnum.capabilities,
	      PropEnum.capacity,
	      PropEnum.connections,
	      PropEnum.connectionString,
	      PropEnum.consumers,
	      PropEnum.contact,
	      PropEnum.contactEMail,
	      PropEnum.contentLocale,
	      PropEnum.creationTime,
	      PropEnum.credential,
	      PropEnum.credentialNamespaces,
	      PropEnum.credentials,
	      PropEnum.dailyPeriod,
	      PropEnum.data,
	      PropEnum.dataSize,
	      PropEnum.dataType,
	      PropEnum.defaultOutputFormat,
	      PropEnum.defaultTriggerDescription,
	      PropEnum.deployedObject,
	      PropEnum.deployedObjectAncestorDefaultNames,
	      PropEnum.deployedObjectClass,
	      PropEnum.deployedObjectDefaultName,
	      PropEnum.deployedObjectStatus,
	      PropEnum.deployedObjectUsage,
	      PropEnum.deploymentOptions,
	      PropEnum.description,
	      PropEnum.disabled,
	      PropEnum.dispatcherID,
	      PropEnum.dispatcherPath,
	      PropEnum.displaySequence,
	      PropEnum.email,
	      PropEnum.endDate,
	      PropEnum.endType,
	      PropEnum.eventID,
	      PropEnum.everyNPeriods,
	      PropEnum.executionFormat,
	      PropEnum.executionLocale,
	      PropEnum.executionPageDefinition,
	      PropEnum.executionPageOrientation,
	      PropEnum.executionPrompt,
	      PropEnum.faxPhone,
	      PropEnum.format,
	      PropEnum.givenName,
	      PropEnum.governors,
	      PropEnum.hasChildren,
	      PropEnum.hasMessage,
	      PropEnum.height,
	      PropEnum.homePhone,
	      PropEnum.horizontalElementsRenderingLimit,
	      PropEnum.identity,
	      PropEnum.isolationLevel,
	      PropEnum.lastConfigurationModificationTime,
	      PropEnum.lastPage,
	      PropEnum.loadBalancingMode,
	      PropEnum.locale,
	      PropEnum.location,
	      PropEnum.members,
	      PropEnum.metadataModel,
	      PropEnum.mobilePhone,
	      PropEnum.model,
	      PropEnum.modelName,
	      PropEnum.modificationTime,
	      PropEnum.monthlyAbsoluteDay,
	      PropEnum.monthlyRelativeDay,
	      PropEnum.monthlyRelativeWeek,
	      PropEnum.name,
	      PropEnum.namespaceFormat,
	      PropEnum.objectClass,
	      PropEnum.output,
	   //does not import if owner is not found   PropEnum.owner,
	      PropEnum.packageBase,
	      PropEnum.page,
	      PropEnum.pageOrientation,
	      PropEnum.pagerPhone,
	      PropEnum.parameters,
	  //we will set the parent explicitly    PropEnum.parent,
	      PropEnum.paths,
	      PropEnum.permissions,
	      PropEnum.policies,
	      PropEnum.portalPage,
	      PropEnum.position,
	      PropEnum.postalAddress,
	      PropEnum.printerAddress,
	      PropEnum.productLocale,
	      PropEnum.qualifier,
	      PropEnum.related,
	      PropEnum.recipientsEMail,
	      PropEnum.recipients,
	      PropEnum.related,
	      PropEnum.replacement,
	      PropEnum.requestedExecutionTime,
	      PropEnum.retentions,
	      PropEnum.rsAffineConnections,
	      PropEnum.rsMaximumProcesses,
	      PropEnum.rsNonAffineConnections,
	      PropEnum.rsQueueLimit,
	      PropEnum.runAsOwner,
	      PropEnum.runningState,
	      PropEnum.runOptions,
	      PropEnum.screenTip,
	//we will set the searchPath      PropEnum.searchPath,
	      PropEnum.searchPathForURL,
	      PropEnum.sequencing,
	      PropEnum.serverGroup,
	      PropEnum.source,
	      PropEnum.specification,
	      PropEnum.startAsActive,
	      PropEnum.startDate,
	      PropEnum.state,
	      PropEnum.status,
	      PropEnum.stepObject,
	      PropEnum.surname,
	      PropEnum.target,
	      PropEnum.taskID,
	      PropEnum.timeZoneID,
	      PropEnum.triggerName,
	      PropEnum.type,
	      PropEnum.unit,
	      PropEnum.uri,
	      PropEnum.usage,
	      PropEnum.user,
	      PropEnum.userCapabilities,
	      PropEnum.userCapability,
	      PropEnum.userName,
	      PropEnum.version,
	      PropEnum.verticalElementsRenderingLimit,
	      PropEnum.viewed,
	      PropEnum.weeklyFriday,
	      PropEnum.weeklyMonday,
	      PropEnum.weeklySaturday,
	      PropEnum.weeklySunday,
	      PropEnum.weeklyThursday,
	      PropEnum.weeklyTuesday,
	      PropEnum.weeklyWednesday,
	      PropEnum.yearlyAbsoluteDay,
	      PropEnum.yearlyAbsoluteMonth,
	      PropEnum.yearlyRelativeDay,
	      PropEnum.yearlyRelativeMonth,
	      PropEnum.yearlyRelativeWeek,
	    };
	    return properties;
	  }
		
	/**
	 * @return Returns the cmService_from.
	 */
	public ContentManagerService_PortType getCmService_from() {
		return cmService_from;
	}
	/**
	 * @return Returns the cmService_to.
	 */
	public ContentManagerService_PortType getCmService_to() {
		return cmService_to;
	}
}
